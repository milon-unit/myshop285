from django.shortcuts import render
from django.shortcuts import render, redirect, get_object_or_404


from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from django.core.paginator import Paginator
from django.core.mail import EmailMessage
from django.utils import timezone
from django.urls import reverse
from .models import User
from .models import *



# Create your views here.
from django.views import View
from django.shortcuts import HttpResponse,redirect

# Create home views here.
def home_page(request):
    products = Product.objects.all()[0:6]
    context = {'products': products}
    return render(request,'index.html',context)

def about_page(request):
    # banner = Homepage.objects.all()
    # context = {'banner': banner},context
    return render(request,'about.html')

def contact_page(request):
    return render(request,'contact.html')

def checkout_page(request):
    return render(request,'checkout.html')

def order_page(request):
    return render(request,'order.html')

# def contact(request):
#     # if request.method == "POST":
#     #     first_name=request.POST.get('first_name')
#     #     last_name=request.POST.get('last_name')
       
#     #     massage=request.POST.get('massage')  
#     #     email=request.POST.get('email')
#     #     cs = Contact(first_name=first_name,last_name=last_name,email=email,massage=massage) 
#     #     cs.save()
#     return render(request,'contact.html')
       

	
	
	
#	home view part end
	
def login_page(request):
	if request.method == "POST":
		username = request.POST.get("username")
		password = request.POST.get("password")
		user = authenticate(request,username=username, password=password)
		if user is not None:
			login(request,user)
			return redirect('profile_page')
		else:
			messages.error(request,"invalid login credentials")
			return redirect('login_page')
	return render(request,'login.html')	
    

def register_page(request):
	if request.method == "POST":
		first_name = request.POST.get('first_name')
		last_name = request.POST.get('last_name')
		username = request.POST.get('username')
		email = request.POST.get('email')
		password = request.POST.get('password')
		user_data_has_error = False
		
		if User.objects.filter(username=username).exists():
			user_data_has_error = True
			messages.error(request, "username already exists")
		
		if User.objects.filter(email=email).exists():
			user_data_has_error = True
			messages.error(request, "Email already exists")
		
		if user_data_has_error:
			return redirect('register_page')
		else:
			new_user = User.objects.create_user(
				first_name=first_name,
				last_name=last_name,
				email=email,
				username=username,
				password=password
			)
			messages.success(request, "Account created. Login now")
			return redirect('login_page')
			
	return render(request,'register.html')


def logout_page(request):
	logout(request)
	return redirect('login_page')

def ForgotPassword(request):

    if request.method == "POST":
        email = request.POST.get('email')

        try:
            user = User.objects.get(email=email)

            new_password_reset = PasswordReset(user=user)
            new_password_reset.save()

            password_reset_url = reverse('reset-password', kwargs={'reset_id': new_password_reset.reset_id})

            full_password_reset_url = f'{request.scheme}://{request.get_host()}{password_reset_url}'

            email_body = f'Reset your password using the link below:\n\n\n{full_password_reset_url}'

            email_message = EmailMessage(
                'Reset your password', # email subject
                email_body,
                settings.EMAIL_HOST_USER, # email sender
                [email] # email  receiver
            )
            email_message.fail_silently = True
            email_message.send()

            return redirect('password-reset-sent', reset_id=new_password_reset.reset_id)

        except User.DoesNotExist:
            messages.error(request, f"No user with email '{email}' found")
            return redirect('forgotpassword')

    return render(request,'forgotpassword.html')


def PasswordResetSent(request,reset_id):
	if PasswordReset.objects.filter(reset_id=reset_id).exists():
		return render(request,'passwordresetsent.html')
	else:
		#redirect to forgot password page if code does not exist
		messages.error(request,'Invalid reset id')
		return redirect('forgotpassword')
	

def ResetPassword(request, reset_id):

    try:
        password_reset_id = PasswordReset.objects.get(reset_id=reset_id)

        if request.method == "POST":
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            passwords_have_error = False

            if password != confirm_password:
                passwords_have_error = True
                messages.error(request, 'Passwords do not match')

            if len(password) < 5:
                passwords_have_error = True
                messages.error(request, 'Password must be at least 5 characters long')

            expiration_time = password_reset_id.created_when + timezone.timedelta(minutes=10)

            if timezone.now() > expiration_time:
                passwords_have_error = True
                messages.error(request, 'Reset link has expired')

                password_reset_id.delete()

            if not passwords_have_error:
                user = password_reset_id.user
                user.set_password(password)
                user.save()

                password_reset_id.delete()

                messages.success(request, 'Password reset. Proceed to login')
                return redirect('login')
            else:
                # redirect back to password reset page and display errors
                return redirect('resetpassword', reset_id=reset_id)


    except PasswordReset.DoesNotExist:

        # redirect to forgot password page if code does not exist
        messages.error(request, 'Invalid reset id')
        return redirect('login')

    return render(request, 'resetpassword.html')
   

	
	
	
# Create login views here.	
	
	
	
def profile_page(request):
    if request.user.is_authenticated:
         return render(request, 'profile.html')
    else:
         return redirect('login_page')
def product_list(request):
    products = Product.objects.all()
    context = {'products': products}
    return render(request, 'products.html', context)

def product_detail(request, id):
    product = Product.objects.get(id=id)
    context = {'product': product}
    return render(request, 'product_details.html', context)

def product_page(request, id):
    product = Product.objects.get(id=id)
    context = {'product': product}
    return render(request, 'product.html', context)
 



def product_update(request,id):
    product = get_object_or_404(Product,pk=id)

    if request.method == "POST":
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('/', pk = product.pk)
        
    else:
        form = ProductForm(instance=product)
    return render(request, 'product_update.html', {'form':form})  	
	
	
	
def category_products(request, slug):
    category = get_object_or_404(Category, slug=slug)
    products = category.products.all()
    return render(request, 'category_products.html', {'category': category, 'products': products})


def shop_page(request):
    products = Product.objects.all()
    # paginator= Paginator(products,6)
    # page_number=request.GET.get('page')
    # page_obj=paginator.get_page(page_number)

    # totalpageNumber=page_obj.paginator.num_pages
    # if request.method=="GET":
    #      st=request.GET.get() 
    #      if st!=None:
    #           products = Product.objects.filter(product_title)
    # data={
    #       'products': page_obj,  
    #     }      
    context = {'products': products}
    return render(request, 'shop.html',context )





@login_required
def add_to_cart(request,id):
    product = get_object_or_404(Product, pk = id)
    session_key = request.session.session_key or request.session.create()
    cart , _ = Cart.objects.get_or_create(session_key=session_key, user = request.user)
    cart_item,created = CartItem.objects.get_or_create(cart=cart,product=product)

    if not created:
        cart_item.quantity +=1
        cart_item.save()
        
    return redirect('cart_page')



def add_to_wishlist(request,id):
    print('id---------', id)
    product = get_object_or_404(Product, pk=id)
    print('product====', product)
    wishlist = Wishlist.objects.get_or_create(user=request.user, product = product)
    print('wishlist=============', wishlist)

    return redirect('wishlist.html')

def update_cart(request,id):
    cart_item = get_object_or_404(CartItem, pk =id,cart___session_key=request.session.session_key)
    new_quantity = int(request.POST.get('quantity', 1))

    if new_quantity > 0:
        cart_item.quantity = new_quantity
        cart_item.save()
    else: 
        cart_item.delete()   
    return redirect('cart_views')    


def remove_cart_item(request,id):
    cart_item = get_object_or_404(CartItem, pk=id)
    cart_item.delete()
    return redirect('cart_page') 




def wishlist_page(request):
    return render(request,'wishlist.html')

@login_required
def cart_page(request):
    cart = CartItem.objects.filter(cart__user = request.user)
    # print('cart=======', cart)
    
    return render(request, 'cart.html', {'cart':cart})


def add_coupon(request):
    code = request.POST.get('code')
    print('code===', code)
    cart = CartItem.objects.get(cart__user=request.user)
    print('cart===', cart)

    if not code:
        return redirect('/')
    try:
        coupon = Coupon.objects.get(code=code,is_active=True)
        print('coupon===', coupon)
        
        if coupon.used_count>= coupon.limit:
            print('coupon======')
            return redirect('/')
        total_price = cart.get_total()
        
        print('total_price===', total_price)
        discount_amount = (coupon.discount/100)* total_price
        print('discount_amount===', discount_amount)
        final_price = total_price - discount_amount
        print('final_price===', final_price)

        coupon.used_count +=1
        coupon.save()

        return redirect('/')
    
    except Coupon.DoesNotExist:
        return redirect('/')


@login_required
def add_to_wishlist(request,id):
    print('id---------', id)
    product = get_object_or_404(Product, pk=id)
    print('product====', product)
    wishlist = Wishlist.objects.get_or_create(user=request.user, product = product)
    print('wishlist=============', wishlist)

    return redirect('/')





    



