from django.db import models
from django.contrib.auth.models import *
# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to="category/image",null=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, related_name = 'children', null=True)
    is_active = models.BooleanField(default=False)


    def __str__(self):
        return self.name



class Product(models.Model):
    COLOR_FIELD = (
        ('RED', 'RED'),
        ('BLUE', 'BLUE'),
        ('YELLOW', 'YELLOW'),
        ('Orange', 'Orange'),
    )
    SIZE_FIELD = (
        ('RED', 'RED'),
        ('BLUE', 'BLUE'),
        ('YELLOW', 'YELLOW'),
        ('Orange', 'Orange'),
    )
    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100)
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    brand = models.CharField(max_length=100, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    additional_description = models.TextField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    purchase_price = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    discount_price = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    color = models.CharField(max_length=50, choices=COLOR_FIELD, null = True)
    size = models.CharField(max_length=50, choices=SIZE_FIELD, null = True)
    quantity = models.PositiveSmallIntegerField(null = True)
    stock = models.IntegerField()



    def save(self, *args, **kwargs):
        self.slug = self.name.replace(" ", "-").lower()
        super(Product, self).save(*args, **kwargs)

    def __str__(self):
        return f"ID NO - {self.id}- {self.name}"



class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add = True)
    updated = models.DateTimeField(auto_now = True)
    session_key = models.CharField(max_length=250)

    def __str__(self):
        return f"Cart ID {self.id}"

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.quantity} of {self.product.name}"


    def get_total(self):
        if self.product.discount_price:
            return self.product.discount_price * self.quantity
        else:
            return self.product.price * self.quantity




		
class Coupon(models.Model):
    code = models.CharField(max_length=50, unique=True)
    discount = models.DecimalField(max_digits=5, decimal_places=2)
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()
    limit = models.PositiveIntegerField(default=1)
    used_count = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField()


    def __str__(self):
        return self.code


class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, verbose_name=("pro"), on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add = True)

    def __str__(self):
        return self.product.name


class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    fname = models.CharField(max_length=100, null=False)
    lname = models.CharField(max_length=100, null=False)
    email = models.CharField(max_length=100, null=False)
    phone = models.CharField(max_length=100, null=False)
    brand = models.CharField(max_length=100, null=False)
    User_adress = models.TextField(blank=True, null=False)
    delevary_adress = models.TextField(blank=True, null=False)
    city = models.CharField(max_length=100, null=False)
    state = models.CharField(max_length=100, null=False)
    country = models.CharField(max_length=100, null=False)
    pincode = models.CharField(max_length=100, null=False)
    total_price = models.CharField(max_length=100, null=False)
    payment_mode = models.CharField(max_length=100, null=False)
    payment_id = models.CharField(max_length=100, null=False)
    orderstatuses = (
       ('PENDING','PENDING'),
        ('PROCESSING','PROCESSING'),
        ('Complete','Complete'),
        ('Cancelled','Cancelled'),
    )
    status = models.CharField(max_length=100, choices=orderstatuses,default='PENDING')
    tracking_no = models.CharField(max_length=100, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return '{} - {}'.format(self.id, self.tracking_no)
    
class Orderitem(models.Model):    
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    price = models.FloatField(null=False)
    quantity = models.IntegerField(null = False)

    def __str__(self):
        return '{} - {}'.format(self.order.id, self.order.tracking_no)


   
