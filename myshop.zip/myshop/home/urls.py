"""
URL configuration for myshop project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from home import views
from django.urls import path
from django.urls import include, path

urlpatterns = [
    path('accounts/', include('allauth.urls')),

	path('', views.home_page, name='home_page'),
	path('about_page/', views.about_page, name='about_page'),
	path('shop_page/', views.shop_page, name='shop_page'),
    path('forgotpassword/', views.ForgotPassword, name='forgotpassword'),
    path('password-reset-sent/<str:reset_id>/',views.PasswordResetSent, name='password-reset-sent'),
    path('reset-password/<str:reset_id>/', views.ResetPassword, name='reset-password'),

	path('contact_page/', views.contact_page, name='contact_page'),

	path('login_page/', views.login_page, name='login_page'),
    path('logout/' , views.logout_page , name="logout_page"),
	path('register_page/', views.register_page, name='register_page'),
	path('product/<int:id>', views.product_page, name='product_page'),
	path('checkout_page/', views.checkout_page, name='checkout_page'),
	path('order_page/', views.order_page, name='order_page'),

	path('remove/cart/item/<int:id>/', views.remove_cart_item, name='remove_cart_item'),
    path('category/<slug:slug>/', views.category_products, name='category_products'),
	path('product/update/<int:id>/', views.product_update, name='product_update'),
    path('add/to/cart/<int:id>/', views.add_to_cart, name='add_to_cart'),
	path('add/wishlist/<int:id>/', views.add_to_wishlist, name='add_to_wishlist'),
	path('cart_page/', views.cart_page, name='cart_page'),
#	path('account_page/', views.account_page, name='account_page'),
	path('profile_page/', views.profile_page, name='profile_page'),
    # path('profile_info/', views.profile_info, name='profile_info'),
	path('wishlist_page/', views.wishlist_page, name='wishlist_page'),
]
